CivExam — ClassName Fix + Mono tint (minimal)
• Corrige l’erreur: _GlassTileCentered introuvable → on utilise une classe publique GlassTileCentered fournie dans ce fichier.
• Teinte les icônes MONO en ColorFilter sur le PRIMARY mono.
Installation:
1) Remplacez lib/screens/play_screen.dart par ce fichier.
2) flutter clean && flutter pub get && flutter run
