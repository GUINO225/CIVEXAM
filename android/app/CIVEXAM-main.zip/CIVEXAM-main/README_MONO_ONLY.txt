Patch minimal (MONO uniquement)
- Ne touche pas vos options ni prefs
- Teinte les icônes MONO en appliquant ColorFilter sur le PRIMARY (assets/icons/mono/*.svg)
- Garde les sets colorés inchangés
Installation:
1) Remplacez lib/screens/play_screen.dart
2) flutter clean && flutter pub get && flutter run
