Mini‑patch — Ajout du bouton “Classement” dans l’AppBar (PlayScreen)

Ce patch ne modifie qu’un seul fichier : lib/screens/play_screen.dart
- Ajoute l’import :  import 'leaderboard_screen.dart';
- Ajoute l’action AppBar : icône trophée -> ouvre LeaderboardScreen()

Application :
1) Remplacez votre fichier par celui fourni.
2) Hot restart.

Reversibilité :
- Si besoin, comparez avec votre play_screen.dart original (aucune autre section n’est touchée).
