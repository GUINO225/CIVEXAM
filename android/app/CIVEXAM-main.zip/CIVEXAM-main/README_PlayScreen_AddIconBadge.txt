Fix PlayScreen: ajout du widget privé _IconBadge (utilisé dans l’entête).
Remplacez `lib/screens/play_screen.dart` par ce fichier puis hot restart.
