CivExam — Bundle PlayScreen + Main
- Remplace `lib/screens/play_screen.dart` et `lib/main.dart`.
- PlayScreen branché sur DesignPrefs + bouton 🎨 (réglages) + 🏆 (classement).
- Main force le démarrage sur le PlayScreen.
Étapes :
1) Copie les 2 fichiers du zip dans ton projet.
2) flutter clean && flutter pub get && flutter run
