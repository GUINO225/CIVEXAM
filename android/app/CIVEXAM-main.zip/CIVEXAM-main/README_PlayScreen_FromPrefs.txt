CivExam — PlayScreen branché sur DesignPrefs
1) Remplacez `lib/screens/play_screen.dart` par ce fichier.
2) Hot restart (ou flutter clean/pub get/run).
Le fond, le blur, les opacités et le “wave” suivent vos préférences (DesignSettingsScreen).
