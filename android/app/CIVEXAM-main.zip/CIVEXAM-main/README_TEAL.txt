CivExam — Set d'icônes SVG 'teal'
Chemin: assets/icons/sets/teal/{play,cap,book,checklist,history,info}.svg
Dans l'app: Réglages design -> Icônes colorées -> 'teal'.
Pense à:
  flutter clean && flutter pub get && flutter run
