CivExam — Set d'icônes SVG 'teal' (flat, sans ombre)
Chemin: assets/icons/sets/teal/{play,cap,book,checklist,history,info}.svg

Utilisation:
- Réglages design -> Icônes colorées -> choisir 'teal' (désactiver le mode 'Icônes monochromes' si besoin).
- Si les couleurs paraissent "grisées", baisse l'opacité verre dans Réglages (ex: fond 0.10, bordure 0.20).
- Redémarre l'app après ajout d'assets: flutter clean && flutter pub get && flutter run
