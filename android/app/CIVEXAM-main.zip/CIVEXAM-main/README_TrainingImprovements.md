# Patch — Entraînement : timing appliqué + historique (5 min)

Contenu :
- lib/models/training_history_entry.dart
- lib/services/training_history_store.dart
- lib/screens/training_history_screen.dart
- lib/screens/training_quick_start.dart
- lib/screens/PLAYSCREEN_PATCH_NOTE.txt

Intégration :
1) Copier-coller ces fichiers.
2) Ajouter le bouton vers TrainingQuickStartScreen dans PlayScreen (voir snippet).
3) flutter clean && flutter pub get && flutter run.
