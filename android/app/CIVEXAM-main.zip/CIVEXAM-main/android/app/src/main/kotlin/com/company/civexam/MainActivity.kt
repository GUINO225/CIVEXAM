package com.company.civexam

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
